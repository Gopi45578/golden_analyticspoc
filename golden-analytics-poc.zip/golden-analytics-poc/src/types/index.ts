// ===== Data Types =====
export interface AgencySpending {
  name: string;
  total: number;
}

export interface CategorySpending {
  name: string;
  total: number;
}

export interface MonthlySpending {
  month: number;
  name: string;
  total: number;
}

export interface VendorSpending {
  name: string;
  total: number;
}

export interface AgencyCategoryBreakdown {
  agency: string;
  categories: CategorySpending[];
}

export interface AgencyMonthlyTrend {
  agency: string;
  months: MonthlySpending[];
}

export interface DataMetadata {
  source: string;
  biennium: string;
  fiscalYear: number;
  totalRecords: number;
  totalSpending: number;
  uniqueAgencies: number;
  uniqueVendors: number;
  uniqueCategories: number;
}

export interface AggregatedData {
  metadata: DataMetadata;
  agencyData: AgencySpending[];
  allAgencyData: AgencySpending[];
  categoryData: CategorySpending[];
  monthlyData: MonthlySpending[];
  vendorData: VendorSpending[];
  allVendorData: VendorSpending[];
  agencyCategoryData: AgencyCategoryBreakdown[];
  agencyMonthlyData: AgencyMonthlyTrend[];
}

// ===== AI Types =====
export type ChartType = 'bar' | 'line' | 'pie' | 'composed';

export interface ChartDataPoint {
  name: string;
  value: number;
  [key: string]: string | number;
}

export interface AIResponse {
  answer: string;
  chartType: ChartType;
  chartData: ChartDataPoint[];
  chartTitle: string;
  queryDescription: string;
  filterLogic: string;
}

export interface AILogEntry {
  id: string;
  timestamp: Date;
  userQuestion: string;
  systemPrompt: string;
  modelInput: string;
  modelResponse: string;
  model: string;
  latencyMs: number;
  status: 'success' | 'error';
  errorMessage?: string;
}

export interface QueryResult {
  loading: boolean;
  error: string | null;
  response: AIResponse | null;
}
