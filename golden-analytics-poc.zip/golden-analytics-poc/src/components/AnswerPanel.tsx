import React from 'react';

interface AnswerPanelProps {
  answer: string;
}

export const AnswerPanel: React.FC<AnswerPanelProps> = ({ answer }) => {
  // Helper to highlight key metric values (e.g. $13.12 billion, 99 agencies, $29.54B)
  const formatText = (text: string) => {
    const parts = text.split(/(\$[0-9.]+\s*(?:billion|million|B|M)?|[0-9,]+\s*(?:vendors|agencies|records)?)/gi);
    return parts.map((part, index) => {
      // Check if it's a dollar amount or number to bold
      const isMetric = /^\$[0-9.]+\s*(?:billion|million|B|M)?$/i.test(part) || 
                       /^[0-9,]+\s*(?:vendors|agencies|records)?$/i.test(part) ||
                       (part.startsWith('$') && part.length > 1);
      
      if (isMetric) {
        return <strong key={index}>{part}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="answer-panel">
      <div className="answer-label">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: '4px' }}>
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
        Answer Narrative
      </div>
      <p className="answer-text">{formatText(answer)}</p>
    </div>
  );
};

export default AnswerPanel;
