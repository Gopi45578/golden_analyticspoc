import React, { useState } from 'react';

interface SqlDrawerProps {
  queryDescription: string;
  filterLogic: string;
}

export const SqlDrawer: React.FC<SqlDrawerProps> = ({
  queryDescription,
  filterLogic
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto' }}>
      <button
        className="sql-drawer-toggle"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className={`arrow ${isOpen ? 'open' : ''}`}>▶</span>
        <span>Show query explanation & logic</span>
      </button>

      {isOpen && (
        <div className="sql-drawer animate-fade-in">
          <div className="sql-drawer-header">
            <span>Query Inspection</span>
          </div>
          <div className="sql-drawer-content">
            <div className="label">Natural Language Logic</div>
            <p style={{ fontSize: '13px', color: '#e6edf3', marginBottom: '14px', lineHeight: 1.5 }}>
              {queryDescription}
            </p>
            
            <div className="label">Calculation Logic / Filters</div>
            <pre>{filterLogic}</pre>
          </div>
        </div>
      )}
    </div>
  );
};

export default SqlDrawer;
