import React from 'react';

interface SuggestedQuestionsProps {
  onSelect: (question: string) => void;
  disabled: boolean;
}

export const SuggestedQuestions: React.FC<SuggestedQuestionsProps> = ({
  onSelect,
  disabled
}) => {
  const suggestions = [
    'Which agencies spent the most?',
    'What did the Health Care Authority spend money on?',
    'Who are the top 10 vendors by payments?',
    'Show the monthly spending trend',
    'How much was spent overall in FY 2022?'
  ];

  return (
    <div className="suggestions animate-fade-in">
      {suggestions.map((q, idx) => (
        <button
          key={idx}
          className="suggestion-chip"
          onClick={() => onSelect(q)}
          disabled={disabled}
        >
          {q}
        </button>
      ))}
    </div>
  );
};

export default SuggestedQuestions;
