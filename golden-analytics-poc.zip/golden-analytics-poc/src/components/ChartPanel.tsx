import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import type { ChartType, ChartDataPoint } from '../types';

interface ChartPanelProps {
  type: ChartType;
  data: ChartDataPoint[];
  title: string;
}

const COLORS = [
  '#58a6ff', // Accent Blue
  '#bc8cff', // Accent Purple
  '#3fb950', // Accent Green
  '#f0883e', // Accent Orange
  '#39d2c0', // Accent Cyan
  '#f778ba', // Pink/Magenta
  '#e2b53e', // Yellow/Gold
  '#58a6ffaa',
  '#bc8cffaa',
  '#3fb950aa'
];

export const ChartPanel: React.FC<ChartPanelProps> = ({ type, data, title }) => {
  // Helper to format currency values for tooltip and axis
  const formatCurrency = (value: number) => {
    if (value >= 1e9) {
      return `$${(value / 1e9).toFixed(2)}B`;
    }
    if (value >= 1e6) {
      return `$${(value / 1e6).toFixed(1)}M`;
    }
    if (value >= 1e3) {
      return `$${(value / 1e3).toFixed(0)}K`;
    }
    return `$${value}`;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div style={{
          backgroundColor: '#161b22',
          border: '1px solid #30363d',
          padding: '12px',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0,0,0,0.5)'
        }}>
          <p style={{ margin: 0, fontWeight: 600, color: '#e6edf3', fontSize: '13px' }}>{label || payload[0].name}</p>
          <p style={{ margin: '4px 0 0 0', color: '#58a6ff', fontSize: '13px', fontWeight: 'bold' }}>
            Amount: {formatCurrency(payload[0].value)}
          </p>
        </div>
      );
    }
    return null;
  };

  const renderChart = () => {
    switch (type) {
      case 'pie':
        return (
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={120}
              fill="#8884d8"
              dataKey="value"
              label={({ name, percent }) => `${(name || '').substring(0, 15)}... (${((percent || 0) * 100).toFixed(0)}%)`}
            >
              {data.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        );
      case 'line':
        return (
          <LineChart data={data} margin={{ top: 10, right: 30, left: 20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#21262d" />
            <XAxis
              dataKey="name"
              stroke="#8b949e"
              fontSize={12}
              tickLine={false}
            />
            <YAxis
              stroke="#8b949e"
              fontSize={12}
              tickLine={false}
              tickFormatter={(v) => formatCurrency(v)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Line
              type="monotone"
              dataKey="value"
              stroke="#58a6ff"
              strokeWidth={3}
              activeDot={{ r: 8 }}
              dot={{ stroke: '#58a6ff', strokeWidth: 2, r: 4, fill: '#0d1117' }}
            />
          </LineChart>
        );
      case 'bar':
      default:
        return (
          <BarChart data={data} margin={{ top: 10, right: 30, left: 20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#21262d" />
            <XAxis
              dataKey="name"
              stroke="#8b949e"
              fontSize={11}
              tickLine={false}
              interval={0}
              tick={({ x, y, payload }) => {
                const text = payload.value.length > 15 ? `${payload.value.substring(0, 12)}...` : payload.value;
                return (
                  <text x={x} y={Number(y) + 12} fill="#8b949e" fontSize={10} textAnchor="middle">
                    {text}
                  </text>
                );
              }}
            />
            <YAxis
              stroke="#8b949e"
              fontSize={12}
              tickLine={false}
              tickFormatter={(v) => formatCurrency(v)}
            />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="value" fill="#58a6ff" radius={[4, 4, 0, 0]}>
              {data.map((_, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        );
    }
  };

  return (
    <div className="chart-panel animate-fade-in-up">
      <h3 className="chart-title">{title}</h3>
      <div className="chart-container">
        <ResponsiveContainer width="100%" height="100%">
          {renderChart()}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ChartPanel;
