import React, { useState } from 'react';
import { getStoredApiKey, setStoredApiKey, clearStoredApiKey } from '../services/aiEngine';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({
  isOpen,
  onClose,
  onSave
}) => {
  const [apiKey, setApiKey] = useState(getStoredApiKey() || '');

  if (!isOpen) return null;

  const handleSave = () => {
    if (apiKey.trim()) {
      setStoredApiKey(apiKey.trim());
      onSave();
      onClose();
    }
  };

  const handleClear = () => {
    clearStoredApiKey();
    setApiKey('');
    onSave();
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <h2>Configure OpenAI API Key</h2>
        <p>
          Connect Budget Lens to OpenAI to get dynamic, natural language analytics. 
          The API key is saved locally in your browser's <code>localStorage</code> and never sent anywhere else.
        </p>

        <input
          type="password"
          className="modal-input"
          placeholder="sk-..."
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
        />

        <div className="modal-actions">
          <button className="modal-btn" onClick={onClose}>Cancel</button>
          {getStoredApiKey() && (
            <button className="modal-btn danger" onClick={handleClear}>Disconnect</button>
          )}
          <button className="modal-btn primary" onClick={handleSave} disabled={!apiKey.trim()}>
            Save Key
          </button>
        </div>

        <div className="modal-note">
          <strong>Note:</strong> If no API key is provided, the app runs on a fast, rule-based local semantic matching engine with preloaded calculation schemas.
        </div>
      </div>
    </div>
  );
};

export default ApiKeyModal;
