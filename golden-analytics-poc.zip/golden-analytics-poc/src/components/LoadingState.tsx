import React from 'react';

export const LoadingState: React.FC = () => {
  return (
    <div className="loading-state animate-fade-in">
      <div className="loading-card">
        <div className="loading-dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
        <p className="loading-text">Analyzing Washington State budget data...</p>
        
        <div className="loading-skeleton">
          <div className="skeleton-line"></div>
          <div className="skeleton-line"></div>
          <div className="skeleton-line"></div>
        </div>
      </div>
    </div>
  );
};

export default LoadingState;
