import React, { useState } from 'react';

interface QuestionBarProps {
  onSearch: (question: string) => void;
  isLoading: boolean;
  initialValue?: string;
}

export const QuestionBar: React.FC<QuestionBarProps> = ({
  onSearch,
  isLoading,
  initialValue = ''
}) => {
  const [question, setQuestion] = useState(initialValue);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (question.trim() && !isLoading) {
      onSearch(question.trim());
    }
  };

  React.useEffect(() => {
    setQuestion(initialValue);
  }, [initialValue]);

  return (
    <div className="question-bar">
      <form onSubmit={handleSubmit}>
        <div className="question-input-wrapper">
          <input
            type="text"
            className="question-input"
            placeholder="Ask anything about WA State spending (e.g. 'Which agencies spent the most?')..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            disabled={isLoading}
          />
          <button
            type="submit"
            className="question-submit"
            disabled={isLoading || !question.trim()}
          >
            {isLoading ? 'Analyzing...' : 'Ask Lens'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default QuestionBar;
