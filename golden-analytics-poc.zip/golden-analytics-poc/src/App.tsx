import React, { useState, useEffect } from 'react';
import aggregatedDataRaw from './data/aggregated.json';
import type { AggregatedData, QueryResult } from './types';
import QuestionBar from './components/QuestionBar';
import SuggestedQuestions from './components/SuggestedQuestions';
import AnswerPanel from './components/AnswerPanel';
import ChartPanel from './components/ChartPanel';
import SqlDrawer from './components/SqlDrawer';
import LoadingState from './components/LoadingState';
import ApiKeyModal from './components/ApiKeyModal';
import { queryWithAI, getStoredApiKey } from './services/aiEngine';
import aiLogger from './services/aiLogger';

const data = aggregatedDataRaw as AggregatedData;

export const App: React.FC = () => {
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [queryResult, setQueryResult] = useState<QueryResult>({
    loading: false,
    error: null,
    response: null
  });
  
  const [hasApiKey, setHasApiKey] = useState(!!getStoredApiKey());
  const [isApiModalOpen, setIsApiModalOpen] = useState(false);
  const [logCount, setLogCount] = useState(0);

  // Load a default overview question on launch
  useEffect(() => {
    handleSearch('How much was spent overall in FY 2022?');
  }, []);

  const handleSearch = async (question: string) => {
    setCurrentQuestion(question);
    setQueryResult({ loading: true, error: null, response: null });

    try {
      const response = await queryWithAI(question, data);
      setQueryResult({
        loading: false,
        error: null,
        response
      });
      // Update count from logger
      setLogCount(aiLogger.getLogCount());
    } catch (err) {
      setQueryResult({
        loading: false,
        error: err instanceof Error ? err.message : 'An error occurred during calculation',
        response: null
      });
    }
  };

  const handleSaveApiKey = () => {
    setHasApiKey(!!getStoredApiKey());
  };

  // Helper to format total spending
  const formatTotalBillion = (total: number) => {
    return `$${(total / 1e9).toFixed(2)}B`;
  };

  return (
    <div className="app animate-fade-in">
      <header className="header">
        <div className="header-brand">
          <div className="header-logo">L</div>
          <div>
            <h1 className="header-title">Budget Lens</h1>
            <span className="header-subtitle">Washington State Fiscal Explorer</span>
          </div>
        </div>

        <div className="header-actions">
          <button
            className={`api-key-btn ${hasApiKey ? 'connected' : ''}`}
            onClick={() => setIsApiModalOpen(true)}
          >
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: hasApiKey ? '#3fb950' : '#8b949e',
              display: 'inline-block'
            }}></span>
            {hasApiKey ? 'AI API Connected' : 'Connect OpenAI API'}
          </button>
          
          <div className="log-count" title="Total AI interaction governance logs recorded in this session">
            Logs: {logCount}
          </div>
        </div>
      </header>

      <section className="hero">
        <div className="hero-badge animate-fade-in">
          <span>★</span> B2B SaaS Data Product Proof-of-Concept
        </div>
        <h1>Turn State Budgets Into Answers</h1>
        <p>
          Budget Lens converts complex government spreadsheet tables into clear narrative reports and charts. Ask anything in plain language — no SQL, no code.
        </p>

        <QuestionBar
          onSearch={handleSearch}
          isLoading={queryResult.loading}
          initialValue={currentQuestion}
        />

        <SuggestedQuestions
          onSelect={handleSearch}
          disabled={queryResult.loading}
        />
      </section>

      {/* Overview Stat Bar */}
      <section className="stats-bar animate-fade-in-up">
        <div className="stat-item">
          <div className="stat-value">{formatTotalBillion(data.metadata.totalSpending)}</div>
          <div className="stat-label">Total Spending (FY 2022)</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">{data.metadata.uniqueAgencies}</div>
          <div className="stat-label">State Agencies</div>
        </div>
        <div className="stat-item">
          <div className="stat-value">{data.metadata.uniqueVendors.toLocaleString()}</div>
          <div className="stat-label">Active Vendors</div>
        </div>
      </section>

      {/* Main content display area */}
      <main style={{ flex: 1 }}>
        {queryResult.loading && <LoadingState />}

        {queryResult.error && (
          <div className="results" style={{ textAlign: 'center', color: '#f87171' }}>
            <p>Error: {queryResult.error}</p>
          </div>
        )}

        {!queryResult.loading && queryResult.response && (
          <div className="results">
            <AnswerPanel answer={queryResult.response.answer} />
            
            <ChartPanel
              type={queryResult.response.chartType}
              data={queryResult.response.chartData}
              title={queryResult.response.chartTitle}
            />

            <SqlDrawer
              queryDescription={queryResult.response.queryDescription}
              filterLogic={queryResult.response.filterLogic}
            />
          </div>
        )}
      </main>

      <footer className="footer">
        <p>
          Built for the Golden Analytics interview loop. Governed by AI interaction logs.
        </p>
      </footer>

      <ApiKeyModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
        onSave={handleSaveApiKey}
      />
    </div>
  );
};

export default App;
