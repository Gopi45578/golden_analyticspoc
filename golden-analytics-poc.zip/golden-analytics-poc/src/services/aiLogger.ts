/**
 * AI Governance Logger
 * 
 * Logs all inputs and outputs to/from AI models.
 * Enterprise B2B governance requirement: all AI interactions must be auditable.
 * 
 * In production, this would persist to a database or log aggregation service
 * (e.g., Elasticsearch, Datadog, or a dedicated audit table in Postgres).
 * For this POC, logs are stored in-memory and output to the browser console.
 */

import type { AILogEntry } from '../types';

class AILogger {
  private logs: AILogEntry[] = [];
  private static instance: AILogger;

  static getInstance(): AILogger {
    if (!AILogger.instance) {
      AILogger.instance = new AILogger();
    }
    return AILogger.instance;
  }

  /**
   * Log an AI interaction. Called before and after every model invocation.
   */
  log(entry: AILogEntry): void {
    this.logs.push(entry);

    // Console output for observability during demo
    const logStyle = entry.status === 'success'
      ? 'color: #4ade80; font-weight: bold;'
      : 'color: #f87171; font-weight: bold;';

    console.group(`%c[AI LOG] ${entry.status.toUpperCase()} — ${entry.id}`, logStyle);
    console.log('Timestamp:', entry.timestamp.toISOString());
    console.log('User Question:', entry.userQuestion);
    console.log('Model:', entry.model);
    console.log('Latency:', `${entry.latencyMs}ms`);
    console.log('System Prompt:', entry.systemPrompt.substring(0, 200) + '...');
    console.log('Model Input:', entry.modelInput.substring(0, 300) + '...');
    console.log('Model Response:', entry.modelResponse.substring(0, 500) + '...');
    if (entry.errorMessage) console.error('Error:', entry.errorMessage);
    console.groupEnd();

    // PRODUCTION TODO: Persist to audit database
    // await auditService.persist(entry);
  }

  /**
   * Get all logs (for potential UI display or export)
   */
  getLogs(): AILogEntry[] {
    return [...this.logs];
  }

  /**
   * Get log count
   */
  getLogCount(): number {
    return this.logs.length;
  }

  /**
   * Generate a unique log ID
   */
  static generateId(): string {
    return `ai-log-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
  }
}

export const aiLogger = AILogger.getInstance();
export default aiLogger;
