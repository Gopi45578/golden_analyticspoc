/**
 * AI Query Engine
 * 
 * Translates natural language questions into data insights using OpenAI.
 * The engine sends the data schema + aggregated summaries to the model,
 * and receives structured JSON with an answer, chart type, and chart data.
 * 
 * Design decision: The AI does NOT generate executable SQL or code.
 * Instead, it analyzes pre-aggregated data and returns display-ready results.
 * This is safer (no injection risk) and faster (no query execution needed).
 * 
 * Falls back to a local keyword-based engine if no API key is configured.
 */

import OpenAI from 'openai';
import type { AIResponse, AggregatedData } from '../types';
import aiLogger from './aiLogger';

const OPENAI_API_KEY_STORAGE_KEY = 'budget-lens-openai-key';

export function getStoredApiKey(): string | null {
  return localStorage.getItem(OPENAI_API_KEY_STORAGE_KEY);
}

export function setStoredApiKey(key: string): void {
  localStorage.setItem(OPENAI_API_KEY_STORAGE_KEY, key);
}

export function clearStoredApiKey(): void {
  localStorage.removeItem(OPENAI_API_KEY_STORAGE_KEY);
}

function buildSystemPrompt(data: AggregatedData): string {
  return `You are Budget Lens, an AI analyst for Washington State government spending data (FY 2022, Biennium 2021-23).

DATASET SUMMARY:
- Total spending: $${(data.metadata.totalSpending / 1e9).toFixed(2)} billion
- ${data.metadata.uniqueAgencies} state agencies
- ${data.metadata.uniqueVendors.toLocaleString()} unique vendors
- ${data.metadata.uniqueCategories} spending categories
- ${data.metadata.totalRecords.toLocaleString()} payment records
- Fiscal Year: ${data.metadata.fiscalYear}

TOP AGENCIES BY SPENDING:
${data.agencyData.slice(0, 15).map((a, i) => `${i + 1}. ${a.name}: $${(a.total / 1e9).toFixed(2)}B`).join('\n')}

SPENDING CATEGORIES:
${data.categoryData.map(c => `- ${c.name}: $${(c.total / 1e9).toFixed(2)}B`).join('\n')}

MONTHLY SPENDING TREND:
${data.monthlyData.map(m => `- ${m.name}: $${(m.total / 1e9).toFixed(2)}B`).join('\n')}

TOP 20 VENDORS:
${data.vendorData.slice(0, 20).map((v, i) => `${i + 1}. ${v.name}: $${(v.total / 1e6).toFixed(1)}M`).join('\n')}

AGENCY CATEGORY BREAKDOWNS (Top 10 agencies):
${data.agencyCategoryData.map(a => `${a.agency}:\n${a.categories.slice(0, 5).map(c => `  - ${c.name}: $${(c.total / 1e6).toFixed(1)}M`).join('\n')}`).join('\n')}

AGENCY MONTHLY TRENDS (Top 5 agencies):
${data.agencyMonthlyData.map(a => `${a.agency}: ${a.months.map(m => `${m.name}=$${(m.total / 1e6).toFixed(0)}M`).join(', ')}`).join('\n')}

RESPONSE FORMAT: You MUST respond with valid JSON only (no markdown, no code blocks). Use this exact structure:
{
  "answer": "A clear, non-technical 2-4 sentence summary answering the user's question. Use plain English. Include specific dollar amounts. Format large numbers as billions/millions.",
  "chartType": "bar" | "line" | "pie",
  "chartData": [{"name": "Label", "value": 12345}],
  "chartTitle": "Short descriptive chart title",
  "queryDescription": "What data operation was performed in plain English",
  "filterLogic": "The logical filter/aggregation in pseudo-code"
}

RULES:
- Always respond with valid JSON, nothing else
- chartData should have 5-15 items max for readability
- Use "bar" for comparisons, "line" for trends over time, "pie" for proportions
- Round dollar values to integers
- Answer in plain, non-technical language suitable for a city councilmember or journalist
- If the question is unclear, make a reasonable interpretation and answer it`;
}

export async function queryWithAI(
  question: string,
  data: AggregatedData
): Promise<AIResponse> {
  const apiKey = getStoredApiKey();

  if (!apiKey) {
    return queryWithLocalEngine(question, data);
  }

  const logId = (aiLogger.constructor as typeof import('./aiLogger').default.constructor).name
    ? `ai-log-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`
    : `ai-log-${Date.now()}`;

  const systemPrompt = buildSystemPrompt(data);
  const userMessage = question;
  const model = 'gpt-4o-mini';
  const startTime = Date.now();

  try {
    const openai = new OpenAI({
      apiKey,
      dangerouslyAllowBrowser: true, // POC only — production would proxy through backend
    });

    const completion = await openai.chat.completions.create({
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage },
      ],
      temperature: 0.3,
      max_tokens: 1500,
      response_format: { type: 'json_object' },
    });

    const latencyMs = Date.now() - startTime;
    const responseText = completion.choices[0]?.message?.content || '{}';

    // GOVERNANCE: Log the complete AI interaction
    aiLogger.log({
      id: logId,
      timestamp: new Date(),
      userQuestion: question,
      systemPrompt,
      modelInput: userMessage,
      modelResponse: responseText,
      model,
      latencyMs,
      status: 'success',
    });

    const parsed = JSON.parse(responseText) as AIResponse;
    return parsed;
  } catch (error) {
    const latencyMs = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';

    // GOVERNANCE: Log failures too
    aiLogger.log({
      id: logId,
      timestamp: new Date(),
      userQuestion: question,
      systemPrompt,
      modelInput: userMessage,
      modelResponse: '',
      model,
      latencyMs,
      status: 'error',
      errorMessage,
    });

    // Fallback to local engine on API error
    console.warn('OpenAI API error, falling back to local engine:', errorMessage);
    return queryWithLocalEngine(question, data);
  }
}

/**
 * Local keyword-based query engine.
 * Used when no OpenAI API key is available, or as a fallback.
 * Demonstrates the architecture without requiring external services.
 */
function queryWithLocalEngine(
  question: string,
  data: AggregatedData
): AIResponse {
  const q = question.toLowerCase();
  const startTime = Date.now();

  let result: AIResponse;

  // Agency-related questions
  if (q.includes('agenc') || q.includes('department') || q.includes('spent the most') || q.includes('biggest spender') || q.includes('top spend')) {
    const top10 = data.agencyData.slice(0, 10);
    result = {
      answer: `The top spending agency in FY 2022 was ${top10[0].name} at $${(top10[0].total / 1e9).toFixed(2)} billion, followed by ${top10[1].name} at $${(top10[1].total / 1e9).toFixed(2)} billion. Together, the top 10 agencies account for the vast majority of the state's $${(data.metadata.totalSpending / 1e9).toFixed(1)}B in spending. Health-related agencies dominate the top of the list.`,
      chartType: 'bar',
      chartData: top10.map(a => ({ name: a.name, value: a.total })),
      chartTitle: 'Top 10 Agencies by Total Spending (FY 2022)',
      queryDescription: 'Aggregated all vendor payments by agency, sorted by total spending descending',
      filterLogic: 'GROUP BY agency | SUM(amount) | ORDER BY total DESC | LIMIT 10',
    };
  }
  // Category questions
  else if (q.includes('categor') || q.includes('type of spend') || q.includes('where does the money') || q.includes('what is the money spent on') || q.includes('breakdown')) {
    result = {
      answer: `Washington State spending in FY 2022 is dominated by "${data.categoryData[0].name}" at $${(data.categoryData[0].total / 1e9).toFixed(2)}B, which includes direct payments to providers and beneficiaries. "${data.categoryData[1]?.name}" comes next at $${(data.categoryData[1]?.total / 1e9).toFixed(2)}B. The total across all categories is $${(data.metadata.totalSpending / 1e9).toFixed(1)}B.`,
      chartType: 'pie',
      chartData: data.categoryData.map(c => ({ name: c.name, value: c.total })),
      chartTitle: 'Spending by Category (FY 2022)',
      queryDescription: 'Aggregated all payments by spending category',
      filterLogic: 'GROUP BY category | SUM(amount) | ORDER BY total DESC',
    };
  }
  // Monthly trend
  else if (q.includes('month') || q.includes('trend') || q.includes('over time') || q.includes('seasonal') || q.includes('when')) {
    result = {
      answer: `Monthly spending in FY 2022 shows variation throughout the year. The highest spending month was ${data.monthlyData.reduce((a, b) => a.total > b.total ? a : b).name} at $${(data.monthlyData.reduce((a, b) => a.total > b.total ? a : b).total / 1e9).toFixed(2)}B. The average monthly spending was $${(data.metadata.totalSpending / 12 / 1e9).toFixed(2)}B.`,
      chartType: 'line',
      chartData: data.monthlyData.map(m => ({ name: m.name, value: m.total })),
      chartTitle: 'Monthly Spending Trend (FY 2022)',
      queryDescription: 'Aggregated payments by fiscal month across all agencies',
      filterLogic: 'GROUP BY month | SUM(amount) | ORDER BY month ASC',
    };
  }
  // Vendor questions
  else if (q.includes('vendor') || q.includes('compan') || q.includes('contractor') || q.includes('paid') || q.includes('who received') || q.includes('supplier')) {
    const top10 = data.vendorData.slice(0, 10);
    result = {
      answer: `The largest vendor by total payments in FY 2022 was ${top10[0].name} receiving $${(top10[0].total / 1e6).toFixed(1)}M. The top 10 vendors combined received a significant portion of state spending. These top vendors are primarily in healthcare, insurance, and infrastructure.`,
      chartType: 'bar',
      chartData: top10.map(v => ({ name: v.name.length > 25 ? v.name.substring(0, 22) + '...' : v.name, value: v.total })),
      chartTitle: 'Top 10 Vendors by Total Payments (FY 2022)',
      queryDescription: 'Aggregated all payments by vendor name, sorted by total descending',
      filterLogic: 'GROUP BY vendor | SUM(amount) | ORDER BY total DESC | LIMIT 10',
    };
  }
  // Health Care Authority specific
  else if (q.includes('health care') || q.includes('healthcare') || q.includes('hca') || q.includes('medicaid')) {
    const hca = data.agencyCategoryData.find(a => a.agency.includes('Health Care'));
    if (hca) {
      result = {
        answer: `The Health Care Authority is the state's largest agency by spending at $${(data.agencyData[0].total / 1e9).toFixed(2)}B in FY 2022, representing ${((data.agencyData[0].total / data.metadata.totalSpending) * 100).toFixed(1)}% of all state spending. Their spending is primarily in ${hca.categories[0].name} ($${(hca.categories[0].total / 1e9).toFixed(2)}B).`,
        chartType: 'bar',
        chartData: hca.categories.slice(0, 8).map(c => ({ name: c.name, value: c.total })),
        chartTitle: 'Health Care Authority Spending by Category',
        queryDescription: 'Filtered to Health Care Authority, then grouped by spending category',
        filterLogic: "WHERE agency = 'Health Care Authority' | GROUP BY category | SUM(amount)",
      };
    } else {
      result = getOverviewResponse(data);
    }
  }
  // Total / overview / summary
  else if (q.includes('total') || q.includes('overview') || q.includes('summary') || q.includes('how much') || q.includes('overall')) {
    result = getOverviewResponse(data);
  }
  // Default: show top agencies
  else {
    result = {
      answer: `Here's an overview of Washington State spending in FY 2022. The state spent a total of $${(data.metadata.totalSpending / 1e9).toFixed(1)} billion across ${data.metadata.uniqueAgencies} agencies, paying ${data.metadata.uniqueVendors.toLocaleString()} unique vendors. The top spender was ${data.agencyData[0].name}. Try asking about specific agencies, vendors, categories, or monthly trends for more detail!`,
      chartType: 'bar',
      chartData: data.agencyData.slice(0, 10).map(a => ({ name: a.name, value: a.total })),
      chartTitle: 'Top 10 Agencies by Spending (FY 2022)',
      queryDescription: 'General overview — showing top agencies by total spending',
      filterLogic: 'GROUP BY agency | SUM(amount) | ORDER BY total DESC | LIMIT 10',
    };
  }

  const latencyMs = Date.now() - startTime;

  // GOVERNANCE: Log local engine usage too
  aiLogger.log({
    id: `local-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
    timestamp: new Date(),
    userQuestion: question,
    systemPrompt: '[Local keyword engine — no AI model used]',
    modelInput: question,
    modelResponse: JSON.stringify(result),
    model: 'local-keyword-engine',
    latencyMs,
    status: 'success',
  });

  return result;
}

function getOverviewResponse(data: AggregatedData): AIResponse {
  return {
    answer: `Washington State spent a total of $${(data.metadata.totalSpending / 1e9).toFixed(1)} billion in FY 2022 across ${data.metadata.uniqueAgencies} agencies. The spending was distributed among ${data.metadata.uniqueVendors.toLocaleString()} vendors across ${data.metadata.uniqueCategories} major categories. The Health Care Authority alone accounts for ${((data.agencyData[0].total / data.metadata.totalSpending) * 100).toFixed(1)}% of all spending.`,
    chartType: 'pie',
    chartData: [
      ...data.agencyData.slice(0, 7).map(a => ({ name: a.name, value: a.total })),
      {
        name: 'All Other Agencies',
        value: data.metadata.totalSpending - data.agencyData.slice(0, 7).reduce((s, a) => s + a.total, 0),
      },
    ],
    chartTitle: 'Total State Spending Distribution (FY 2022)',
    queryDescription: 'Overview of total spending distribution across all agencies',
    filterLogic: 'GROUP BY agency | SUM(amount) | TOP 7 + Others',
  };
}
