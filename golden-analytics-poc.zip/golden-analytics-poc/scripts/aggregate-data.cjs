// Script to pre-aggregate the 451K row CSV into manageable JSON summaries
const fs = require('fs');
const path = require('path');

const csvPath = '/home/ajay/Downloads/Vendor-Payments_2021-23(FY 2022).csv';
const raw = fs.readFileSync(csvPath, 'utf-8');
const lines = raw.split('\n').filter(l => l.trim());

// Parse CSV handling quoted fields
function parseCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      inQuotes = !inQuotes;
    } else if (ch === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  result.push(current.trim());
  return result;
}

const headers = parseCSVLine(lines[0]);
console.log('Headers:', headers);

const rows = [];
for (let i = 1; i < lines.length; i++) {
  const fields = parseCSVLine(lines[i]);
  if (fields.length >= 11) {
    rows.push({
      biennium: fields[0],
      fiscalYear: parseInt(fields[1]) || 2022,
      month: parseInt(fields[2]) || 1,
      agencyCode: fields[3],
      agency: fields[4].trim(),
      objectCode: fields[5],
      category: fields[6].trim(),
      subobjCode: fields[7],
      subCategory: fields[8].trim(),
      vendor: fields[9].trim(),
      amount: parseFloat(fields[10].replace(/[^0-9.-]/g, '')) || 0
    });
  }
}

console.log(`Parsed ${rows.length} rows`);

// 1. Spending by Agency (top 20)
const byAgency = {};
rows.forEach(r => {
  byAgency[r.agency] = (byAgency[r.agency] || 0) + r.amount;
});
const agencyData = Object.entries(byAgency)
  .map(([name, total]) => ({ name, total: Math.round(total) }))
  .sort((a, b) => b.total - a.total);

// 2. Spending by Category
const byCategory = {};
rows.forEach(r => {
  byCategory[r.category] = (byCategory[r.category] || 0) + r.amount;
});
const categoryData = Object.entries(byCategory)
  .map(([name, total]) => ({ name, total: Math.round(total) }))
  .sort((a, b) => b.total - a.total);

// 3. Spending by Month
const byMonth = {};
rows.forEach(r => {
  const key = r.month;
  byMonth[key] = (byMonth[key] || 0) + r.amount;
});
const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const monthlyData = Object.entries(byMonth)
  .map(([m, total]) => ({ month: parseInt(m), name: monthNames[parseInt(m)-1] || `M${m}`, total: Math.round(total) }))
  .sort((a, b) => a.month - b.month);

// 4. Top 20 Vendors
const byVendor = {};
rows.forEach(r => {
  byVendor[r.vendor] = (byVendor[r.vendor] || 0) + r.amount;
});
const vendorData = Object.entries(byVendor)
  .map(([name, total]) => ({ name, total: Math.round(total) }))
  .sort((a, b) => b.total - a.total);

// 5. Spending by SubCategory per Agency (top 10 agencies)
const top10Agencies = agencyData.slice(0, 10).map(a => a.name);
const agencyCategoryBreakdown = {};
rows.forEach(r => {
  if (top10Agencies.includes(r.agency)) {
    const key = r.agency;
    if (!agencyCategoryBreakdown[key]) agencyCategoryBreakdown[key] = {};
    agencyCategoryBreakdown[key][r.category] = (agencyCategoryBreakdown[key][r.category] || 0) + r.amount;
  }
});
const agencyCategoryData = Object.entries(agencyCategoryBreakdown).map(([agency, cats]) => ({
  agency,
  categories: Object.entries(cats).map(([cat, total]) => ({ name: cat, total: Math.round(total) })).sort((a,b) => b.total - a.total)
}));

// 6. Monthly trend per top 5 agencies
const top5Agencies = agencyData.slice(0, 5).map(a => a.name);
const agencyMonthly = {};
rows.forEach(r => {
  if (top5Agencies.includes(r.agency)) {
    if (!agencyMonthly[r.agency]) agencyMonthly[r.agency] = {};
    agencyMonthly[r.agency][r.month] = (agencyMonthly[r.agency][r.month] || 0) + r.amount;
  }
});
const agencyMonthlyData = Object.entries(agencyMonthly).map(([agency, months]) => ({
  agency,
  months: Object.entries(months).map(([m, total]) => ({
    month: parseInt(m),
    name: monthNames[parseInt(m)-1],
    total: Math.round(total)
  })).sort((a, b) => a.month - b.month)
}));

// Summary stats
const totalSpending = Math.round(rows.reduce((s, r) => s + r.amount, 0));
const uniqueAgencies = new Set(rows.map(r => r.agency)).size;
const uniqueVendors = new Set(rows.map(r => r.vendor)).size;
const uniqueCategories = new Set(rows.map(r => r.category)).size;

const output = {
  metadata: {
    source: 'Washington State Vendor Payments FY 2022',
    biennium: '2021-23',
    fiscalYear: 2022,
    totalRecords: rows.length,
    totalSpending,
    uniqueAgencies,
    uniqueVendors,
    uniqueCategories,
  },
  agencyData: agencyData.slice(0, 30),
  allAgencyData: agencyData,
  categoryData,
  monthlyData,
  vendorData: vendorData.slice(0, 30),
  allVendorData: vendorData.slice(0, 100),
  agencyCategoryData,
  agencyMonthlyData,
};

const outPath = path.join(__dirname, '..', 'src', 'data', 'aggregated.json');
fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
console.log(`\nWrote aggregated data to ${outPath}`);
console.log(`Total spending: $${(totalSpending / 1e9).toFixed(2)}B`);
console.log(`Agencies: ${uniqueAgencies}, Vendors: ${uniqueVendors}, Categories: ${uniqueCategories}`);
console.log(`Top 5 agencies:`, agencyData.slice(0, 5).map(a => `${a.name}: $${(a.total/1e9).toFixed(2)}B`));
